package dropdown;


import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import base.BaseTests;

public class DropDownTests extends BaseTests{
	
	@Test
	void testSelectoption() {
		String option ="Option 1";
		var dropDownPage = homePage.clickDropdown();
		dropDownPage.selectFromDropDown(option);
		var selectedOptions = dropDownPage.getSelectedOptions();
		assertEquals(selectedOptions.size(),1, "Incorrect number of selections");
		assertTrue(selectedOptions.contains(option), "Option not selected");
		
	}
	
	@Test
	void testSelectoption123() {
		String option ="Option 1";
		var dropDownPage = homePage.clickDropdown();
		dropDownPage.selectFromDropDown(option);
		var selectedOptions = dropDownPage.getSelectedOptions();
		assertEquals(selectedOptions.size(),1, "Incorrect number of selections");
		assertTrue(selectedOptions.contains(option), "Option not selected");
		
	}
		
	
}

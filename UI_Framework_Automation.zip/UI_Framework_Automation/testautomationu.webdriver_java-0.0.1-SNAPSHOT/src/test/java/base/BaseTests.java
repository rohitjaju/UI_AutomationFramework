package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import com.applitools.eyes.selenium.Eyes;
import com.google.common.io.Files;

import pages.HomePage;
import utils.CucumberRunner;

public class BaseTests {
	
    private WebDriver driver;
    protected HomePage homePage;
    int failcount = 0;
    protected static Eyes eyes;

	public Properties props = System.getProperties();
    
    @BeforeClass
    public void setUp() {
    	System.setProperty("webdriver.chrome.driver", "resources/chromedriver.exe");
    	driver = new ChromeDriver();
    	
    	goHome();
    	System.out.println(driver.getTitle());
    	try {
    		props.load(new FileInputStream(new File("resources/test.properties")));
    	}
    	catch (Exception e){
    		
    	}
    	initiateEyes();
    }
    
    @BeforeMethod
    public void goHome(){
    	driver.get("https://the-internet.herokuapp.com/");
    	driver.manage().window().maximize();   	
    	homePage = new HomePage(driver);  	
    }
    
    @AfterMethod
    public void takeScreenshot(ITestResult result) throws IOException {
    	
    	if(ITestResult.FAILURE == result.getStatus()) {	
    	try {
    		//failcount = failcount+ITestResult.FAILURE;
    		var camera = (TakesScreenshot)driver;
    		File screenshot = camera.getScreenshotAs(OutputType.FILE);
    		System.out.println("Screenshot Taken:"+screenshot.getAbsolutePath()); 
    		Files.move(screenshot, new File("C:\\UI_Framework_Automation\\testautomationu.webdriver_java-0.0.1-SNAPSHOT\\resources\\screenshots\\"+result.getName()+".png"));
    	}
    		catch (Exception e) {
				// TODO: handle exception
    		}
    	}  		
  
    }
    @AfterClass
    public void tearDown() {
		driver.quit();
	}
    
    	private static void initiateEyes() {
    		eyes= new Eyes();
    		eyes.setApiKey(System.getProperty("applitools.api.key"));
    	}
    	
    	public void validateWindow() {
    		eyes.open(driver, "LoginApp",Thread.currentThread().getStackTrace()[2].getMethodName());
    		eyes.checkWindow();
    		eyes.close();
    	}
    
    	
    
}

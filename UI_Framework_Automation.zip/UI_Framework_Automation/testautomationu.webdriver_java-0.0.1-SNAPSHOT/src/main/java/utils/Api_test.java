package utils;

import static org.hamcrest.Matchers.*;
import org.testng.annotations.Test;


//import io.cucumber.datatable.DataTable;
import static io.restassured.RestAssured.given;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;


import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;


public class Api_test {
	private Response response;	
	
	
@Test	
	/*@When("^User hit the webservices$") 
	public void requestUsZipCode90210_checkPlaceNameInResponseBody_expectBeverlyHills() {
	    given().
        when().
        	get("http://zippopotam.us/us/90210").
        then().
        assertThat().
        	contentType(ContentType.JSON).
        body("places[0].'place name'", equalTo("Beverly Hills")).log().all();
    }*/


//@When("^User hit the webservices$")
public void user_hit_the_webservices() {
	 given().
     when().
     	get("http://zippopotam.us/us/90210").
     then().
     assertThat().
     	contentType(ContentType.JSON).
     body("places[0].'place name'", equalTo("Beverly Hills")).log().all();
    throw new io.cucumber.java.PendingException();
}

@Test
public void user_hit_the_webservices1() {
	 given().
    when().
    	get("http://zippopotam.us/us/90210").
    then().
    assertThat().
    	contentType(ContentType.JSON).
    body("places[0].'place name'", equalTo("Beverly Hills")).log().all();
   throw new io.cucumber.java.PendingException();
}

}
